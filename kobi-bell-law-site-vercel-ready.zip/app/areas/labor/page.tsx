import Section from "@/components/Section";
export const metadata = {
  title: "דיני עבודה | קובי בל – משרד עורכי דין",
  description: "זכויות עובדים, פיצויי פיטורים, שימוע, בונוסים והסכמים.",
};
export default function Page() {
  return (
    <Section title="דיני עבודה" subtitle="זכויות עובדים, פיצויי פיטורים, שימוע, בונוסים והסכמים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>זכויות עובדים, פיצויי פיטורים, שימוע, בונוסים והסכמים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
