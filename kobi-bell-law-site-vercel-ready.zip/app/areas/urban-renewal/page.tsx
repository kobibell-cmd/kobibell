import Section from "@/components/Section";
export const metadata = {
  title: "התחדשות עירונית | קובי בל – משרד עורכי דין",
  description: "פינוי‑בינוי ותמ"א 38 – ייצוג דיירים ויזמים.",
};
export default function Page() {
  return (
    <Section title="התחדשות עירונית" subtitle="פינוי‑בינוי ותמ"א 38 – ייצוג דיירים ויזמים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>פינוי‑בינוי ותמ"א 38 – ייצוג דיירים ויזמים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
