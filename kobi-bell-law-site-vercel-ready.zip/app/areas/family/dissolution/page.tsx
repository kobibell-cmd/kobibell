import Section from "@/components/Section";
export const metadata = {
  title: "התרת נישואין | קובי בל – משרד עורכי דין",
  description: "בקשות להתרת נישואין בבית המשפט לענייני משפחה.",
};
export default function Page() {
  return (
    <Section title="התרת נישואין" subtitle="בקשות להתרת נישואין בבית המשפט לענייני משפחה.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>בקשות להתרת נישואין בבית המשפט לענייני משפחה.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
