import Section from "@/components/Section";
export const metadata = {
  title: "סכסוכים משפחתיים | קובי בל – משרד עורכי דין",
  description: "ניהול סכסוכים משפחתיים ומנגנוני גישור/בוררות.",
};
export default function Page() {
  return (
    <Section title="סכסוכים משפחתיים" subtitle="ניהול סכסוכים משפחתיים ומנגנוני גישור/בוררות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ניהול סכסוכים משפחתיים ומנגנוני גישור/בוררות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
