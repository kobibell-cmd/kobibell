import Section from "@/components/Section";
export const metadata = {
  title: "הסכם ממון לפני נישואין | קובי בל – משרד עורכי דין",
  description: "עריכת הסכמי ממון טרום-נישואין.",
};
export default function Page() {
  return (
    <Section title="הסכם ממון לפני נישואין" subtitle="עריכת הסכמי ממון טרום-נישואין.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>עריכת הסכמי ממון טרום-נישואין.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
