import Section from "@/components/Section";
export const metadata = {
  title: "הסכם ידועים בציבור | קובי בל – משרד עורכי דין",
  description: "הסכמות משפטיות למעמד ידועים בציבור.",
};
export default function Page() {
  return (
    <Section title="הסכם ידועים בציבור" subtitle="הסכמות משפטיות למעמד ידועים בציבור.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>הסכמות משפטיות למעמד ידועים בציבור.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
