import Section from "@/components/Section";
export const metadata = {
  title: "נדל"ן ומקרקעין | קובי בל – משרד עורכי דין",
  description: "עסקאות מכר/רכש, ליווי פרויקטים, רישום בטאבו, היטלי השבחה.",
};
export default function Page() {
  return (
    <Section title="נדל"ן ומקרקעין" subtitle="עסקאות מכר/רכש, ליווי פרויקטים, רישום בטאבו, היטלי השבחה.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>עסקאות מכר/רכש, ליווי פרויקטים, רישום בטאבו, היטלי השבחה.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
