import Section from "@/components/Section";
export const metadata = {
  title: "צו קיום צוואה | קובי בל – משרד עורכי דין",
  description: "הליכים למתן צו קיום לצוואות.",
};
export default function Page() {
  return (
    <Section title="צו קיום צוואה" subtitle="הליכים למתן צו קיום לצוואות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>הליכים למתן צו קיום לצוואות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
