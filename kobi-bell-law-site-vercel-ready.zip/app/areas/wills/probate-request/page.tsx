import Section from "@/components/Section";
export const metadata = {
  title: "בקשה לצו ירושה | קובי בל – משרד עורכי דין",
  description: "הכנת והגשת בקשות לצו ירושה לרשם לענייני ירושה.",
};
export default function Page() {
  return (
    <Section title="בקשה לצו ירושה" subtitle="הכנת והגשת בקשות לצו ירושה לרשם לענייני ירושה.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>הכנת והגשת בקשות לצו ירושה לרשם לענייני ירושה.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
