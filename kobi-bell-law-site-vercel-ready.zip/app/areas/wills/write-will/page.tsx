import Section from "@/components/Section";
export const metadata = {
  title: "עריכת צוואה | קובי בל – משרד עורכי דין",
  description: "ליווי בעריכת צוואות – בכתב יד, בפני עדים או בפני רשות.",
};
export default function Page() {
  return (
    <Section title="עריכת צוואה" subtitle="ליווי בעריכת צוואות – בכתב יד, בפני עדים או בפני רשות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ליווי בעריכת צוואות – בכתב יד, בפני עדים או בפני רשות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
