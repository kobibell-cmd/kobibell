import Section from "@/components/Section";
export const metadata = {
  title: "עורך דין ירושה | קובי בל – משרד עורכי דין",
  description: "ייעוץ מקיף בתחומי ירושה ועיזבון.",
};
export default function Page() {
  return (
    <Section title="עורך דין ירושה" subtitle="ייעוץ מקיף בתחומי ירושה ועיזבון.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייעוץ מקיף בתחומי ירושה ועיזבון.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
