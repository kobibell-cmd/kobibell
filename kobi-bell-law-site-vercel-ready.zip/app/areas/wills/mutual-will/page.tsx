import Section from "@/components/Section";
export const metadata = {
  title: "צוואה הדדית | קובי בל – משרד עורכי דין",
  description: "ייעוץ והסדרת צוואות הדדיות לבני זוג.",
};
export default function Page() {
  return (
    <Section title="צוואה הדדית" subtitle="ייעוץ והסדרת צוואות הדדיות לבני זוג.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייעוץ והסדרת צוואות הדדיות לבני זוג.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
