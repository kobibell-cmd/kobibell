import Section from "@/components/Section";
export const metadata = {
  title: "התנגדות לצוואה | קובי בל – משרד עורכי דין",
  description: "ייצוג בהליכי התנגדות על בסיס פגמים/כשירות/השפעה בלתי הוגנת.",
};
export default function Page() {
  return (
    <Section title="התנגדות לצוואה" subtitle="ייצוג בהליכי התנגדות על בסיס פגמים/כשירות/השפעה בלתי הוגנת.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייצוג בהליכי התנגדות על בסיס פגמים/כשירות/השפעה בלתי הוגנת.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
