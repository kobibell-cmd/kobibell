import Section from "@/components/Section";
export const metadata = {
  title: "עורך דין צוואה | קובי בל – משרד עורכי דין",
  description: "ייעוץ בעריכת צוואות תקפות ומותאמות אישית.",
};
export default function Page() {
  return (
    <Section title="עורך דין צוואה" subtitle="ייעוץ בעריכת צוואות תקפות ומותאמות אישית.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייעוץ בעריכת צוואות תקפות ומותאמות אישית.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
