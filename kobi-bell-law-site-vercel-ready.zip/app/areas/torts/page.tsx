import Section from "@/components/Section";
export const metadata = {
  title: "נזיקין | קובי בל – משרד עורכי דין",
  description: "תאונות דרכים, רשלנות מקצועית, נזקי גוף ורכוש.",
};
export default function Page() {
  return (
    <Section title="נזיקין" subtitle="תאונות דרכים, רשלנות מקצועית, נזקי גוף ורכוש.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>תאונות דרכים, רשלנות מקצועית, נזקי גוף ורכוש.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
