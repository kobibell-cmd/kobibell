import Section from "@/components/Section";
export const metadata = {
  title: "תביעות אזרחיות | קובי בל – משרד עורכי דין",
  description: "תביעות כספיות, לשון הרע, סכסוכים קנייניים ועוד.",
};
export default function Page() {
  return (
    <Section title="תביעות אזרחיות" subtitle="תביעות כספיות, לשון הרע, סכסוכים קנייניים ועוד.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>תביעות כספיות, לשון הרע, סכסוכים קנייניים ועוד.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
