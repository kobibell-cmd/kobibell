import Section from "@/components/Section";
export const metadata = {
  title: "ליקויי בנייה | קובי בל – משרד עורכי דין",
  description: "מומחים, חוות דעת וייצוג בתביעות ליקויים.",
};
export default function Page() {
  return (
    <Section title="ליקויי בנייה" subtitle="מומחים, חוות דעת וייצוג בתביעות ליקויים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>מומחים, חוות דעת וייצוג בתביעות ליקויים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
