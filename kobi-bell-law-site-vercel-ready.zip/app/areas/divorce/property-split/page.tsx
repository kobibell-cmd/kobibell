import Section from "@/components/Section";
export const metadata = {
  title: "חלוקת רכוש בגירושין | קובי בל – משרד עורכי דין",
  description: "איזון משאבים, שיתוף ספציפי וראיות פיננסיות.",
};
export default function Page() {
  return (
    <Section title="חלוקת רכוש בגירושין" subtitle="איזון משאבים, שיתוף ספציפי וראיות פיננסיות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>איזון משאבים, שיתוף ספציפי וראיות פיננסיות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
