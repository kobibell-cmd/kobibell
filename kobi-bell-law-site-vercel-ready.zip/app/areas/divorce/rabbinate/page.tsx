import Section from "@/components/Section";
export const metadata = {
  title: "הליך גירושין ברבנות | קובי בל – משרד עורכי דין",
  description: "ניהול ההליך בבתי הדין הרבניים לצד זירות אזרחיות.",
};
export default function Page() {
  return (
    <Section title="הליך גירושין ברבנות" subtitle="ניהול ההליך בבתי הדין הרבניים לצד זירות אזרחיות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ניהול ההליך בבתי הדין הרבניים לצד זירות אזרחיות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
