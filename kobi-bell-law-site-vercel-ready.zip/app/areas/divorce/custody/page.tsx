import Section from "@/components/Section";
export const metadata = {
  title: "משמורת | קובי בל – משרד עורכי דין",
  description: "אסטרטגיה לחזקת ילדים, זמני שהות והסכמות יציבות.",
};
export default function Page() {
  return (
    <Section title="משמורת" subtitle="אסטרטגיה לחזקת ילדים, זמני שהות והסכמות יציבות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>אסטרטגיה לחזקת ילדים, זמני שהות והסכמות יציבות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
