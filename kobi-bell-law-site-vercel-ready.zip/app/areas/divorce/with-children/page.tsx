import Section from "@/components/Section";
export const metadata = {
  title: "גירושין עם ילדים | קובי בל – משרד עורכי דין",
  description: "שמירה על טובת הקטינים והמשכיות הורית.",
};
export default function Page() {
  return (
    <Section title="גירושין עם ילדים" subtitle="שמירה על טובת הקטינים והמשכיות הורית.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>שמירה על טובת הקטינים והמשכיות הורית.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
