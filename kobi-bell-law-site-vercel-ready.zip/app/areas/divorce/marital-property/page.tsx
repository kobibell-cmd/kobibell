import Section from "@/components/Section";
export const metadata = {
  title: "יחסי ממון ותביעות | קובי בל – משרד עורכי דין",
  description: "מחלוקות רכושיות בין בני זוג והליכים נלווים.",
};
export default function Page() {
  return (
    <Section title="יחסי ממון ותביעות" subtitle="מחלוקות רכושיות בין בני זוג והליכים נלווים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>מחלוקות רכושיות בין בני זוג והליכים נלווים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
