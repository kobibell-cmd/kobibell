import Section from "@/components/Section";
export const metadata = {
  title: "הסכם גירושין | קובי בל – משרד עורכי דין",
  description: "ליווי ועריכת הסכמי גירושין הוגנים ואכיפים.",
};
export default function Page() {
  return (
    <Section title="הסכם גירושין" subtitle="ליווי ועריכת הסכמי גירושין הוגנים ואכיפים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ליווי ועריכת הסכמי גירושין הוגנים ואכיפים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
