import Section from "@/components/Section";
export const metadata = {
  title: "מזונות ומדור | קובי בל – משרד עורכי דין",
  description: "בניית תביעה/הגנה מושכלת בהתאם לפסיקה עדכנית.",
};
export default function Page() {
  return (
    <Section title="מזונות ומדור" subtitle="בניית תביעה/הגנה מושכלת בהתאם לפסיקה עדכנית.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>בניית תביעה/הגנה מושכלת בהתאם לפסיקה עדכנית.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
