import Section from "@/components/Section";
export const metadata = {
  title: "הסכם ממון | קובי בל – משרד עורכי דין",
  description: "הסדרת יחסי ממון והגנה על נכסים.",
};
export default function Page() {
  return (
    <Section title="הסכם ממון" subtitle="הסדרת יחסי ממון והגנה על נכסים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>הסדרת יחסי ממון והגנה על נכסים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
