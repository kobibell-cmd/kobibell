import Section from "@/components/Section";
export const metadata = {
  title: "גישור גירושין | קובי בל – משרד עורכי דין",
  description: "יישוב סכסוך בהסכמה, תוך צמצום עלויות וקונפליקט.",
};
export default function Page() {
  return (
    <Section title="גישור גירושין" subtitle="יישוב סכסוך בהסכמה, תוך צמצום עלויות וקונפליקט.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>יישוב סכסוך בהסכמה, תוך צמצום עלויות וקונפליקט.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
