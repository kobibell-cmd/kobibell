import Section from "@/components/Section";
export const metadata = {
  title: "חוזים ומשפט אזרחי | קובי בל – משרד עורכי דין",
  description: "ניסוח חוזים, ניהול סכסוכים והליכים אזרחיים.",
};
export default function Page() {
  return (
    <Section title="חוזים ומשפט אזרחי" subtitle="ניסוח חוזים, ניהול סכסוכים והליכים אזרחיים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ניסוח חוזים, ניהול סכסוכים והליכים אזרחיים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
