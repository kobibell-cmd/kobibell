import Section from "@/components/Section";
export const metadata = {
  title: "מדיניות פרטיות | קובי בל – משרד עורכי דין",
  description: "מדיניות פרטיות תבניתית – להתאמה אישית.",
};
export default function Page() {
  return (
    <Section title="מדיניות פרטיות" subtitle="מדיניות פרטיות תבניתית – להתאמה אישית.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>מדיניות פרטיות תבניתית – להתאמה אישית.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
