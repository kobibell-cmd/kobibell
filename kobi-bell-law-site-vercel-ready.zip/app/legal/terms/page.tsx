import Section from "@/components/Section";
export const metadata = {
  title: "תקנון אתר | קובי בל – משרד עורכי דין",
  description: "תקנון שימוש באתר – טיוטה ראשונית.",
};
export default function Page() {
  return (
    <Section title="תקנון אתר" subtitle="תקנון שימוש באתר – טיוטה ראשונית.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>תקנון שימוש באתר – טיוטה ראשונית.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
