import Section from "@/components/Section";
export const metadata = {
  title: "מפת אתר | קובי בל – משרד עורכי דין",
  description: "סקירה מרוכזת של קישורי האתר.",
};
export default function Page() {
  return (
    <Section title="מפת אתר" subtitle="סקירה מרוכזת של קישורי האתר.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>סקירה מרוכזת של קישורי האתר.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
