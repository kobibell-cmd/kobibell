import Section from "@/components/Section";
export const metadata = {
  title: "מחיקת רישום פלילי | קובי בל – משרד עורכי דין",
  description: "פנייה לחנינה/התיישנות/מחיקה בהתאם לחוק המרשם.",
};
export default function Page() {
  return (
    <Section title="מחיקת רישום פלילי" subtitle="פנייה לחנינה/התיישנות/מחיקה בהתאם לחוק המרשם.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>פנייה לחנינה/התיישנות/מחיקה בהתאם לחוק המרשם.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
