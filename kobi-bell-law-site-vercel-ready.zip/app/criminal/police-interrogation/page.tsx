import Section from "@/components/Section";
export const metadata = {
  title: "חקירה באזהרה | קובי בל – משרד עורכי דין",
  description: "הכנה וייצוג בחקירות, שמירה על זכויות החשוד.",
};
export default function Page() {
  return (
    <Section title="חקירה באזהרה" subtitle="הכנה וייצוג בחקירות, שמירה על זכויות החשוד.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>הכנה וייצוג בחקירות, שמירה על זכויות החשוד.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
