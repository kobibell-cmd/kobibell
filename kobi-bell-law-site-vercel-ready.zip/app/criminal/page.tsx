import Section from "@/components/Section";
export const metadata = {
  title: "מחלקה פלילית | קובי בל – משרד עורכי דין",
  description: "ייעוץ וליווי בייצוג פלילי – 24/7 במקרי חירום.",
};
export default function Page() {
  return (
    <Section title="מחלקה פלילית" subtitle="ייעוץ וליווי בייצוג פלילי – 24/7 במקרי חירום.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייעוץ וליווי בייצוג פלילי – 24/7 במקרי חירום.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
