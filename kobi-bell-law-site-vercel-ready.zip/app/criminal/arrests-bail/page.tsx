import Section from "@/components/Section";
export const metadata = {
  title: "מעצרים ושחרורים | קובי בל – משרד עורכי דין",
  description: "דיוני מעצר, שחרור בערובה ותנאים מגבילים.",
};
export default function Page() {
  return (
    <Section title="מעצרים ושחרורים" subtitle="דיוני מעצר, שחרור בערובה ותנאים מגבילים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>דיוני מעצר, שחרור בערובה ותנאים מגבילים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
