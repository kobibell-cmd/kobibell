import Section from "@/components/Section";
export const metadata = {
  title: "עבירות צווארון לבן | קובי בל – משרד עורכי דין",
  description: "חקירות רשות ניירות ערך, עבירות מרמה, הלבנת הון.",
};
export default function Page() {
  return (
    <Section title="עבירות צווארון לבן" subtitle="חקירות רשות ניירות ערך, עבירות מרמה, הלבנת הון.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>חקירות רשות ניירות ערך, עבירות מרמה, הלבנת הון.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
