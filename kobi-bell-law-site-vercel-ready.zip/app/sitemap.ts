import type { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://example.com';
  const routes = [
    '/', '/about', '/team', '/testimonials', '/contact',
    '/areas/real-estate','/areas/labor','/areas/torts','/areas/contracts','/areas/urban-renewal','/areas/defects','/areas/civil',
    '/areas/divorce/settlement','/areas/divorce/custody','/areas/divorce/prenup','/areas/divorce/mediation','/areas/divorce/with-children','/areas/divorce/rabbinate','/areas/divorce/child-support','/areas/divorce/property-split','/areas/divorce/marital-property',
    '/areas/family/dissolution','/areas/family/prenup-before','/areas/family/disputes','/areas/family/common-law',
    '/areas/wills/inheritance-lawyer','/areas/wills/will-lawyer','/areas/wills/probate-request','/areas/wills/write-will','/areas/wills/objection','/areas/wills/probate-order','/areas/wills/mutual-will',
    '/criminal','/criminal/police-interrogation','/criminal/arrests-bail','/criminal/record-expungement','/criminal/white-collar',
    '/kimberly','/kimberly/family-services','/kimberly/articles',
    '/media/articles','/media/video','/media/radio','/media/podcasts',
    '/legal/privacy','/legal/terms','/sitemap'
  ];
  return routes.map((url) => ({
    url: base + url,
    lastModified: new Date(),
    changeFrequency: 'weekly',
    priority: url === '/' ? 1 : 0.7,
  }));
}
