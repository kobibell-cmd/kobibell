import Section from "@/components/Section";
export const metadata = {
  title: "אודות המשרד | קובי בל – משרד עורכי דין",
  description: "ייצוג משפטי אזרחי עם דגש על תוצאה, זמינות ושקיפות.",
};
export default function Page() {
  return (
    <Section title="אודות המשרד" subtitle="ייצוג משפטי אזרחי עם דגש על תוצאה, זמינות ושקיפות.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייצוג משפטי אזרחי עם דגש על תוצאה, זמינות ושקיפות.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
