import Section from "@/components/Section";
export const metadata = {
  title: "צור קשר | קובי בל – משרד עורכי דין",
  description: "טל' 054-5427765 • הרצל 36, בית גור, אשקלון • סניף מודיעין.",
};
export default function Page() {
  return (
    <Section title="צור קשר" subtitle="טל' 054-5427765 • הרצל 36, בית גור, אשקלון • סניף מודיעין.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>טל' 054-5427765 • הרצל 36, בית גור, אשקלון • סניף מודיעין.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
