import Section from "@/components/Section";
export const metadata = {
  title: "צוות המשרד | קובי בל – משרד עורכי דין",
  description: "קובי בל, עו"ד – מייסד ובעלים. קימברלי בל, עו"ד – ראש מחלקת דיני משפחה. צוות מסייע מקצועי.",
};
export default function Page() {
  return (
    <Section title="צוות המשרד" subtitle="קובי בל, עו"ד – מייסד ובעלים. קימברלי בל, עו"ד – ראש מחלקת דיני משפחה. צוות מסייע מקצועי.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>קובי בל, עו"ד – מייסד ובעלים. קימברלי בל, עו"ד – ראש מחלקת דיני משפחה. צוות מסייע מקצועי.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
