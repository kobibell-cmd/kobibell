import Section from "@/components/Section";
import ContactForm from "@/components/ContactForm";
import Link from "next/link";

export default function Page(){
  return (
    <div>
      <section className="bg-gradient-to-b from-white to-gray-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-snug">
              המשרד המוביל באשקלון והסביבה<br/>עם הצלחות מוכחות – וזמינות מיידית
            </h1>
            <p className="mt-4 text-lg text-gray-600">
              ייעוץ וליווי משפטי אזרחי: נדל"ן, דיני משפחה, דיני עבודה, נזיקין, חוזים ופלילי. מיקוד בתוצאה ושירות אישי.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <Link href="/contact" className="rounded-2xl bg-gray-900 text-white px-6 py-3 text-base font-semibold hover:bg-black">דברו איתנו</Link>
              <a href="https://wa.me/972545427765" target="_blank" className="rounded-2xl border border-gray-300 px-6 py-3 text-base font-semibold hover:bg-gray-100">וואטסאפ</a>
            </div>
            <ul className="mt-6 grid sm:grid-cols-3 gap-3 text-sm text-gray-700">
              <li className="flex items-center gap-2">✓ ייצוג אגרסיבי ומדויק</li>
              <li className="flex items-center gap-2">✓ ניסיון רחב בתחומי האזרחי</li>
              <li className="flex items-center gap-2">✓ שקיפות מלאה וזמינות</li>
            </ul>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] w-full rounded-3xl bg-white shadow-xl ring-1 ring-black/5 grid place-items-center">
              <div className="text-center p-8">
                <div className="mx-auto w-24 h-24 rounded-2xl bg-gray-900 text-white grid place-items-center text-3xl font-bold">KB</div>
                <p className="mt-4 text-sm text-gray-500">החלף בתמונת משרד אמיתית עם לוגו בלבד</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Section id="areas" title="תחומי התמחות" subtitle="ליווי מקיף לכל צורך משפטי אזרחי – באשקלון, מודיעין והמרכז.">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {["נדל"ן ומקרקעין","נזיקין","דיני עבודה","דיני משפחה","חוזים ומשפט אזרחי","התחדשות עירונית","ליקויי בנייה","פלילי"].map((t,i)=>(
            <div key={i} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-black/5 hover:shadow-md transition">
              <p className="font-semibold text-lg">{t}</p>
              <p className="mt-2 text-sm text-gray-600">שירות אישי, אסטרטגיה חכמה ומיקוד בתוצאה.</p>
            </div>
          ))}
        </div>
      </Section>

      <Section id="proof" title="הצלחות אחרונות">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { t: "הפחתת מזונות מ‑7,000 ל‑1,900 ₪", d: "ניהול מו"מ חכם והצגת ראיות עדכניות." },
            { t: "ייצוג רוכשים בעסקת מכר מורכבת", d: "שמירה על זכויות הלקוחות בפרויקט נדל"ן מאתגר." },
            { t: "ניצחון בהתנגדות לתכנון ובנייה", d: "עצירת תכנית פוגענית והחזרת הנושא לדיון." },
          ].map((c,i)=>(
            <div key={i} className="rounded-3xl border border-gray-200 p-6">
              <p className="font-semibold">{c.t}</p>
              <p className="mt-2 text-sm text-gray-600">{c.d}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section id="contact" title="צור קשר" subtitle="מענה מהיר ושקוף. ניתן ליצור קשר טלפונית, בוואטסאפ או בטופס.">
        <ContactForm />
      </Section>
    </div>
  );
}
