import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "קובי בל – משרד עורכי דין אזרחי, נדל"ן ונזיקין | אשקלון ומודיעין",
  description: "ייעוץ וליווי משפטי אזרחי: נדל"ן, משפחה, עבודה, נזיקין ופלילי. זמינות מיידית ושירות אישי. טל' 054-5427765.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <body className="bg-gray-50 text-gray-900">
        <Header />
        <main>{children}</main>
        <Footer />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{__html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LegalService",
            "name": "קובי בל – משרד עורכי דין",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "הרצל 36, בית גור",
              "addressLocality": "אשקלון",
              "addressCountry": "IL"
            },
            "areaServed": ["אשקלון","מודיעין","מרכז"],
            "telephone": "+972545427765",
            "url": "https://example.com",
            "openingHours": "Mo-Fr 08:30-19:00",
          })}}
        />
      </body>
    </html>
  );
}
