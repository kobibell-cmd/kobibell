import Section from "@/components/Section";
export const metadata = {
  title: "אודות עו"ד קימברלי בל | קובי בל – משרד עורכי דין",
  description: "ראש מחלקת דיני משפחה – ניסיון בליטיגציה, מזונות, משמורת והסכמים.",
};
export default function Page() {
  return (
    <Section title="אודות עו"ד קימברלי בל" subtitle="ראש מחלקת דיני משפחה – ניסיון בליטיגציה, מזונות, משמורת והסכמים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ראש מחלקת דיני משפחה – ניסיון בליטיגציה, מזונות, משמורת והסכמים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
