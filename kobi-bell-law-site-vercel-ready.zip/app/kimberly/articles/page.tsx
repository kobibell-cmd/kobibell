import Section from "@/components/Section";
export const metadata = {
  title: "מאמרים – קימברלי בל | קובי בל – משרד עורכי דין",
  description: "מאמרים מקצועיים ועדכונים בדיני משפחה.",
};
export default function Page() {
  return (
    <Section title="מאמרים – קימברלי בל" subtitle="מאמרים מקצועיים ועדכונים בדיני משפחה.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>מאמרים מקצועיים ועדכונים בדיני משפחה.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
