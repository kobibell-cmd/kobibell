import Section from "@/components/Section";
export const metadata = {
  title: "שירותי דיני משפחה – קימברלי בל | קובי בל – משרד עורכי דין",
  description: "ייעוץ, ייצוג וגישור בסכסוכי משפחה.",
};
export default function Page() {
  return (
    <Section title="שירותי דיני משפחה – קימברלי בל" subtitle="ייעוץ, ייצוג וגישור בסכסוכי משפחה.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ייעוץ, ייצוג וגישור בסכסוכי משפחה.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
