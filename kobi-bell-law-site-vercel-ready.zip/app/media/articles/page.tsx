import Section from "@/components/Section";
export const metadata = {
  title: "כתבות ומאמרים | קובי בל – משרד עורכי דין",
  description: "פרסומים וכתבות מהתקשורת.",
};
export default function Page() {
  return (
    <Section title="כתבות ומאמרים" subtitle="פרסומים וכתבות מהתקשורת.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>פרסומים וכתבות מהתקשורת.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
