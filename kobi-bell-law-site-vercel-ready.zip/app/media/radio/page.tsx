import Section from "@/components/Section";
export const metadata = {
  title: "רדיו | קובי בל – משרד עורכי דין",
  description: "ראיונות ותכניות רדיו.",
};
export default function Page() {
  return (
    <Section title="רדיו" subtitle="ראיונות ותכניות רדיו.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>ראיונות ותכניות רדיו.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
