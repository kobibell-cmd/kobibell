import Section from "@/components/Section";
export const metadata = {
  title: "וידאו | קובי בל – משרד עורכי דין",
  description: "קטעי וידאו מהתקשורת ומופעי מדיה.",
};
export default function Page() {
  return (
    <Section title="וידאו" subtitle="קטעי וידאו מהתקשורת ומופעי מדיה.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>קטעי וידאו מהתקשורת ומופעי מדיה.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
