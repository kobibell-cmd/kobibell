import Section from "@/components/Section";
export const metadata = {
  title: "פודקאסטים | קובי בל – משרד עורכי דין",
  description: "הופעות והשתתפויות בפודקאסטים.",
};
export default function Page() {
  return (
    <Section title="פודקאסטים" subtitle="הופעות והשתתפויות בפודקאסטים.">
      <div className="prose prose-neutral max-w-none" dir="rtl">
        <p>הופעות והשתתפויות בפודקאסטים.</p>
        <p>לתיאום ייעוץ: 054-5427765.</p>
      </div>
    </Section>
  );
}
